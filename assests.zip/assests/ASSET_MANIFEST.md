# Say It — Asset Library

Use this folder as the canonical visual asset library for future AI coding/design agents.

## Naming convention
Files are numbered by importance/use order. Prefer the specifically named production asset over extracting from an asset sheet.

## Asset map

- **01_character_relaxed_chair_laptop.png** — Privacy section / relaxed character; isolated transparent artwork. (1145×1374, RGBA)
- **02_background_pastel_abstract_decorations.png** — General website decorative background; soft pastel blobs. (1536×1024, RGBA)
- **03_brand_logo_mark.png** — Standalone Say It logo symbol/mark. (1369×1149, RGBA)
- **04_handwritten_less_typing_more_doing.png** — Privacy section handwritten decoration. (1774×887, RGBA)
- **05_app_window_ui_mockup.png** — Hero section desktop app-window visual reference. (1536×1024, RGBA)
- **06_character_relaxed_desk_laptop.png** — Privacy section character + desk/laptop composition. (1145×1374, RGBA)
- **07_feature_icons_set.png** — Feature-card icon set: speed, privacy, paste, language, clean. (2048×682, RGBA)
- **08_handwritten_think_it_say_it_done.png** — Hero section handwritten decoration. (1396×1127, RGBA)
- **09_asset_sheet_master_5000x5000.png** — Reference/master asset sheet; use for visual reference, not final cropped assets. (1254×1254, RGBA)
- **10_background_pastel_environment_scene.png** — Privacy/marketing environmental background; pastel city/plants scene. (1536×1024, RGBA)
- **11_handwritten_ideas_flow_better_spoken.png** — Download CTA handwritten decoration. (1536×1024, RGBA)
- **12_asset_sheet_master_4096x4096.png** — Reference/master asset sheet; use for visual reference, not final cropped assets. (1254×1254, RGBA)
- **13_character_thinking_laptop.png** — Hero section main character pose; transparent artwork. (1024×1536, RGBA)
- **14_brand_logo_full_wordmark.png** — Full Say It logo with symbol + wordmark. (2048×682, RGBA)

## Important usage rules

- `01_character_relaxed_chair_laptop.png` and `06_character_relaxed_desk_laptop.png` are different compositions; use the one that matches the screenshot section.
- `13_character_thinking_laptop.png` is the main hero/working character asset.
- `05_app_window_ui_mockup.png` is a visual master/reference. For the real app, recreate the UI in code when possible rather than using the image as the interactive UI.
- `02_background_pastel_abstract_decorations.png` is for soft general decorative shapes.
- `10_background_pastel_environment_scene.png` is for environmental/marketing sections.
- `08_handwritten_think_it_say_it_done.png`, `04_handwritten_less_typing_more_doing.png`, and `11_handwritten_ideas_flow_better_spoken.png` are standalone decorative typography.
- `03_brand_logo_mark.png` is the standalone symbol; `14_brand_logo_full_wordmark.png` is the complete logo.
- The two asset sheets are reference sheets only. Do not crop production assets from them if a dedicated asset exists.
- A duplicate of `08_handwritten_think_it_say_it_done.png` was supplied and intentionally omitted from the canonical library because it is byte-identical.

## For future AI agents

When implementing the Say It website/app, inspect this manifest first and use the named asset whose purpose matches the target section. Do not substitute generic illustrations when a matching asset exists. Preserve transparent backgrounds and do not embed these images into a screenshot-based page; use them as individual assets.